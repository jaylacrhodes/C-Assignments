﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Currency_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDollars.Clear();
            lblCurrency.Text= String.Empty;
            lblCurrencyName.Text= String.Empty;
            picCurrency.Image = null;
        }

        private void btnPound_Click(object sender, EventArgs e)
        {
            picCurrency.Image = Properties.Resources.uk;
            lblCurrencyName.Text = "Pounds";
            double currency;
            CultureInfo cul=new CultureInfo("en-GB");
            currency = Convert.ToDouble(txtDollars.Text) * 0.63;
            lblCurrency.Text = currency.ToString("c",cul);

        }

        private void btnMarks_Click(object sender, EventArgs e)
        {
            picCurrency.Image = Properties.Resources.germany;
            lblCurrencyName.Text = "Marks";
            double currency;
            CultureInfo cul = new CultureInfo("de-DE");
            currency = Convert.ToDouble(txtDollars.Text) * 1.82;
            lblCurrency.Text = currency.ToString("c",cul);
        }

        private void btnFrancs_Click(object sender, EventArgs e)
        {
            picCurrency.Image = Properties.Resources.france;
            lblCurrencyName.Text = "Francs";
            double currency;
            CultureInfo cul = new CultureInfo("fr-FR");
            currency = Convert.ToDouble(txtDollars.Text) * 6.12;
            lblCurrency.Text = currency.ToString("c",cul);
        }

        private void btnYen_Click(object sender, EventArgs e)
        {
            picCurrency.Image = Properties.Resources.japan;
            lblCurrencyName.Text = "Yen";
            double currency;
            CultureInfo cul = new CultureInfo("ja-JP");
            currency = Convert.ToDouble(txtDollars.Text) * 120.85;
            lblCurrency.Text = currency.ToString("c",cul);
        }

        private void btnCanada_Click(object sender, EventArgs e)
        {
            picCurrency.Image = Properties.Resources.canada;
            lblCurrencyName.Text = "Canadian Dollar";
            double currency;
            CultureInfo cul = new CultureInfo("en-CA");
            currency = Convert.ToDouble(txtDollars.Text) * 1.37;
            lblCurrency.Text = currency.ToString("c",cul);
        }
    }
}
