﻿namespace Currency_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picUS = new System.Windows.Forms.PictureBox();
            this.picCurrency = new System.Windows.Forms.PictureBox();
            this.btnPound = new System.Windows.Forms.Button();
            this.btnMarks = new System.Windows.Forms.Button();
            this.btnFrancs = new System.Windows.Forms.Button();
            this.btnYen = new System.Windows.Forms.Button();
            this.btnCanada = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblDollars = new System.Windows.Forms.Label();
            this.lblCurrencyName = new System.Windows.Forms.Label();
            this.txtDollars = new System.Windows.Forms.TextBox();
            this.lblCurrency = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picUS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCurrency)).BeginInit();
            this.SuspendLayout();
            // 
            // picUS
            // 
            this.picUS.Image = global::Currency_Converter.Properties.Resources.usa;
            this.picUS.Location = new System.Drawing.Point(114, 63);
            this.picUS.Name = "picUS";
            this.picUS.Size = new System.Drawing.Size(185, 87);
            this.picUS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picUS.TabIndex = 0;
            this.picUS.TabStop = false;
            // 
            // picCurrency
            // 
            this.picCurrency.Location = new System.Drawing.Point(114, 182);
            this.picCurrency.Name = "picCurrency";
            this.picCurrency.Size = new System.Drawing.Size(185, 90);
            this.picCurrency.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCurrency.TabIndex = 1;
            this.picCurrency.TabStop = false;
            // 
            // btnPound
            // 
            this.btnPound.Location = new System.Drawing.Point(224, 318);
            this.btnPound.Name = "btnPound";
            this.btnPound.Size = new System.Drawing.Size(75, 23);
            this.btnPound.TabIndex = 2;
            this.btnPound.Text = "Pounds";
            this.btnPound.UseVisualStyleBackColor = true;
            this.btnPound.Click += new System.EventHandler(this.btnPound_Click);
            // 
            // btnMarks
            // 
            this.btnMarks.Location = new System.Drawing.Point(366, 318);
            this.btnMarks.Name = "btnMarks";
            this.btnMarks.Size = new System.Drawing.Size(75, 23);
            this.btnMarks.TabIndex = 3;
            this.btnMarks.Text = "Marks";
            this.btnMarks.UseVisualStyleBackColor = true;
            this.btnMarks.Click += new System.EventHandler(this.btnMarks_Click);
            // 
            // btnFrancs
            // 
            this.btnFrancs.Location = new System.Drawing.Point(527, 318);
            this.btnFrancs.Name = "btnFrancs";
            this.btnFrancs.Size = new System.Drawing.Size(75, 23);
            this.btnFrancs.TabIndex = 4;
            this.btnFrancs.Text = "Francs";
            this.btnFrancs.UseVisualStyleBackColor = true;
            this.btnFrancs.Click += new System.EventHandler(this.btnFrancs_Click);
            // 
            // btnYen
            // 
            this.btnYen.Location = new System.Drawing.Point(294, 373);
            this.btnYen.Name = "btnYen";
            this.btnYen.Size = new System.Drawing.Size(75, 23);
            this.btnYen.TabIndex = 5;
            this.btnYen.Text = "Yen";
            this.btnYen.UseVisualStyleBackColor = true;
            this.btnYen.Click += new System.EventHandler(this.btnYen_Click);
            // 
            // btnCanada
            // 
            this.btnCanada.Location = new System.Drawing.Point(446, 373);
            this.btnCanada.Name = "btnCanada";
            this.btnCanada.Size = new System.Drawing.Size(75, 23);
            this.btnCanada.TabIndex = 6;
            this.btnCanada.Text = "Canada";
            this.btnCanada.UseVisualStyleBackColor = true;
            this.btnCanada.Click += new System.EventHandler(this.btnCanada_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(664, 355);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblDollars
            // 
            this.lblDollars.AutoSize = true;
            this.lblDollars.Location = new System.Drawing.Point(397, 98);
            this.lblDollars.Name = "lblDollars";
            this.lblDollars.Size = new System.Drawing.Size(50, 16);
            this.lblDollars.TabIndex = 8;
            this.lblDollars.Text = "Dollars";
            // 
            // lblCurrencyName
            // 
            this.lblCurrencyName.AutoSize = true;
            this.lblCurrencyName.Location = new System.Drawing.Point(424, 220);
            this.lblCurrencyName.Name = "lblCurrencyName";
            this.lblCurrencyName.Size = new System.Drawing.Size(0, 16);
            this.lblCurrencyName.TabIndex = 9;
            // 
            // txtDollars
            // 
            this.txtDollars.Location = new System.Drawing.Point(527, 95);
            this.txtDollars.Name = "txtDollars";
            this.txtDollars.Size = new System.Drawing.Size(100, 22);
            this.txtDollars.TabIndex = 10;
            // 
            // lblCurrency
            // 
            this.lblCurrency.AutoSize = true;
            this.lblCurrency.Location = new System.Drawing.Point(527, 220);
            this.lblCurrency.Name = "lblCurrency";
            this.lblCurrency.Size = new System.Drawing.Size(0, 16);
            this.lblCurrency.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblCurrency);
            this.Controls.Add(this.txtDollars);
            this.Controls.Add(this.lblCurrencyName);
            this.Controls.Add(this.lblDollars);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCanada);
            this.Controls.Add(this.btnYen);
            this.Controls.Add(this.btnFrancs);
            this.Controls.Add(this.btnMarks);
            this.Controls.Add(this.btnPound);
            this.Controls.Add(this.picCurrency);
            this.Controls.Add(this.picUS);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Currency Converter";
            ((System.ComponentModel.ISupportInitialize)(this.picUS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCurrency)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picUS;
        private System.Windows.Forms.PictureBox picCurrency;
        private System.Windows.Forms.Button btnPound;
        private System.Windows.Forms.Button btnMarks;
        private System.Windows.Forms.Button btnFrancs;
        private System.Windows.Forms.Button btnYen;
        private System.Windows.Forms.Button btnCanada;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblDollars;
        private System.Windows.Forms.Label lblCurrencyName;
        private System.Windows.Forms.TextBox txtDollars;
        private System.Windows.Forms.Label lblCurrency;
    }
}

