﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Celsius_and_Fahrenheit_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCtoF_Click(object sender, EventArgs e)
        {
            double celsius = Convert.ToDouble(txtTemperature.Text);
            double fahrenheit = (9.0 / 5.0) * celsius + 32;
            lblTempConverted.Text = fahrenheit.ToString("F2");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblTempConverted.Text= string.Empty;
            txtTemperature.Text= string.Empty;
        }

        private void btnFtoC_Click(object sender, EventArgs e)
        {
            double fahrenheit = Convert.ToDouble(txtTemperature.Text);
            double celsius = (5.0 / 9.0) * fahrenheit - 32;
            lblTempConverted.Text = celsius.ToString("F2");
        }
    }
}
